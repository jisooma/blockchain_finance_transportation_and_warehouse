package org.fisco.bcos.contracts;

import org.fisco.bcos.constants.GasConstants;
import org.fisco.bcos.web3j.crypto.Credentials;
import org.fisco.bcos.web3j.protocol.Web3j;
import org.fisco.bcos.web3j.protocol.core.methods.response.TransactionReceipt;
import org.fisco.bcos.web3j.tuples.generated.Tuple4;
import org.fisco.bcos.web3j.tuples.generated.Tuple6;
import org.fisco.bcos.web3j.tx.gas.StaticGasProvider;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

/**
 * @author mazhixiu
 * @date 2021/4/1 17:10
 * @Email:861359297@qq.com
 */
public class WarehouseReciptHashCall {
    private static Web3j web3j;
    private static Credentials credentials;
    private static  WarehouseReciptHashCall  WarehouseReciptHashCall;
    private String contractAddress;
    // WarehouseReciptHash合约
    private  WarehouseReciptHash  WarehouseReciptHash;

    public WarehouseReciptHashCall() throws Exception {
        if(loadContract()){
            System.out.println("alreadly deployed, loaded successfully");
        }else {
            System.out.println("deploying");
        }
        if(this.WarehouseReciptHash==null){
            if (!this.deployContract())
                System.out.println("deploying error");
        }
    }
    //加载合约实例
    public boolean loadContract(){
        if(this.contractAddress!=null&&!this.contractAddress.isEmpty()){
            //加载合约
            this.WarehouseReciptHash= WarehouseReciptHash.load(this.contractAddress,web3j,credentials,new StaticGasProvider(
                    GasConstants.GAS_PRICE, GasConstants.GAS_LIMIT));
            System.out.println("-------------WarehouseReciptHash合约地址----------------address is: " + this.WarehouseReciptHash.getContractAddress());
            if(this.WarehouseReciptHash!=null){
                return true;
            }else{
                return false;
            }
        }
        return  false;
    }
    //部署合约
    public boolean deployContract() throws Exception {
        // deploy contract
        //合约为空
        if (this.WarehouseReciptHash==null){
            this.WarehouseReciptHash =  WarehouseReciptHash.deploy(web3j,credentials, new StaticGasProvider(GasConstants.GAS_PRICE, GasConstants.GAS_LIMIT)).send();
            System.out.println("--------------------WarehouseReciptHash--------address is: " +  WarehouseReciptHash.getContractAddress());
            this.contractAddress = this.WarehouseReciptHash.getContractAddress();
            return  true;
        }
        return false;
    }
    public  static  WarehouseReciptHashCall  getInstance(Web3j web3j,Credentials credentials) throws Exception {
       WarehouseReciptHashCall.web3j = web3j;
       WarehouseReciptHashCall.credentials=  credentials;
        //
        if(WarehouseReciptHashCall == null){
           WarehouseReciptHashCall = new WarehouseReciptHashCall();
        }
        return WarehouseReciptHashCall;
    }
    public void setWarehouseReciptHash(BigInteger id,  String hash, String updateTime) throws Exception {
        TransactionReceipt transactionReceipt= WarehouseReciptHash.setWarehouseReciptHash(id,hash,updateTime).send();
        System.out.println(transactionReceipt.getOutput());
        System.out.println("##################");
        System.out.println(transactionReceipt.getInput());
        BigInteger bn=transactionReceipt.getBlockNumber();
        String th =transactionReceipt.getTransactionHash();
        String from=transactionReceipt.getFrom();
        //updateTime
        System.out.println();
        //将这些数据放在数据库里，便于查询。
    }

    public Map<String, String> getWarehouseReciptHash(BigInteger id) throws Exception {
        System.out.println(id);
        Tuple4<BigInteger, BigInteger, String, String> res=WarehouseReciptHash.getWarehouseReciptHash(id).send();
        Map<String, String> result = new HashMap<String, String>();
        result.put("no",String.valueOf(res.getValue1()));
        result.put("id",String.valueOf(res.getValue2()));
        result.put("hash",res.getValue3());
        result.put("updateTime",res.getValue4());
        System.out.println(result);
        return result;
    }

    //返回合同对应的hash
    public String CompareWarehouseReciptHash(BigInteger id) throws Exception {
        System.out.println(id);
        Tuple4<BigInteger, BigInteger, String, String> res=WarehouseReciptHash.getWarehouseReciptHash(id).send();
        System.out.println(res.getValue3());
        return res.getValue3();
    }
}
