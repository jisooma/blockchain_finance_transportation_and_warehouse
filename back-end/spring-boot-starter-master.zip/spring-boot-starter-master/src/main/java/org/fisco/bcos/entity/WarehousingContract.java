package org.fisco.bcos.entity;

import java.sql.Timestamp;

/**
 * @author mazhixiu
 * @date 2021/3/25 11:19
 * @Email:861359297@qq.com
 */
//仓储合同
public class WarehousingContract {


}
