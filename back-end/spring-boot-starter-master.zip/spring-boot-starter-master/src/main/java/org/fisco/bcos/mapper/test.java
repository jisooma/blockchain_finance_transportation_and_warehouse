package org.fisco.bcos.mapper;

/**
 * @author mazhixiu
 * @date 2021/3/14 14:35
 * @Email:861359297@qq.com
 */
public interface test {
}
