package org.fisco.bcos.service;

import org.apache.ibatis.annotations.Param;
import org.fisco.bcos.entity.LoanContract;

import java.sql.Timestamp;
import java.util.List;

/**
 * @author mazhixiu
 * @date 2021/3/26 10:46
 * @Email:861359297@qq.com
 */
public interface LoanContractService {
    public int addLoanContract(LoanContract LoanContract);
    public int updateLoanContract(LoanContract LoanContract);
    public List<LoanContract> queryAllLoanContract();
    public LoanContract queryLoanContractByID(int id);
    public LoanContract queryLoanContractByReciptID(int id);
    public List<LoanContract> queryLoanContractByStatus(String status);
    public List<LoanContract> queryLoanContractByEnterprise(String enterprise);
    public List<LoanContract> queryLoanContractByBank( String bank);
    public List<LoanContract> queryLoanContractByBankAndEnterprise( String bank,String enterprise);
    public LoanContract queryLoanContractByBankAndEnterpriseAndTime( String bank, String enterprise, Timestamp ts);
    public List<LoanContract> queryLoanContractByBankAndStatus(String bank, String status);
    public List<LoanContract> queryLoanContractByEnterpriseAndStatus( String enterprise, String status);
    public List<LoanContract> queryLoanContractByBankAndEnterpriseAndStatus(String bank,String enterprise,String status);
}
