package org.fisco.bcos.service;

;
import org.apache.ibatis.annotations.Param;
import org.fisco.bcos.entity.LoanRecipt;

import java.sql.Timestamp;
import java.util.List;

public interface LoanReciptService {
    public int addLoanRecipt(LoanRecipt loanRecipt);
    public int updateLoanRecipt(LoanRecipt loanRecipt);
    public int deleteLoanRecipt( int id);
    public List<LoanRecipt> queryAllLoanRecipt();
    public List<LoanRecipt> queryLoanReciptByEnterpirse( String enterprise);
    public List<LoanRecipt> queryLoanReciptByenterpriseAndBank(String enterprise, String bank);
    public LoanRecipt queryLoanReciptByenterpriseAndBankAndTime(String enterprise, String bank, Timestamp time);
    public List<LoanRecipt> queryLoanReciptByBank(String bank);
    public LoanRecipt queryLoanReciptByID( int id);
    public List<LoanRecipt> queryLoanReciptByEnterpirseAndStatus( String enterprise,String status);
    public List<LoanRecipt> queryLoanReciptByStatus( String status);
    public List<LoanRecipt> queryLoanReciptByBankAndStatus( String bank, String status);
    public LoanRecipt queryLoanReciptByloanID(int loanID);
}
