package org.fisco.bcos.service;

import org.apache.ibatis.annotations.Param;
import org.fisco.bcos.entity.OrderContract;

import java.util.List;

/**
 * @author mazhixiu
 * @date 2021/3/30 10:40
 * @Email:861359297@qq.com
 */
public interface OrderContractService {
    public int addOrderContract(OrderContract OrderContract);
    public int updateOrderContract(OrderContract OrderContract);
    public List<OrderContract> queryOrderContractBySupplier(String supplier);
    public List<OrderContract> queryOrderContractBySupplierAndStatus(String supplier, String status);
    public List<OrderContract> queryOrderContractByBuyer( String buyer);
    public List<OrderContract> queryOrderContractByBuyerAndStatus(String buyer, String status);
    public List<OrderContract> queryAllOrderContract();
    public OrderContract queryOrderContractById( int id);
    public OrderContract queryOrderContractByUUId(String id);
    public OrderContract queryOrderContractByStatus( String status);
    public List<OrderContract> queryMyOrderContract(String name);
    public int deleteOrderContract(int id);

}
