package org.fisco.bcos.service;


import org.fisco.bcos.entity.OrderItem;

import java.util.List;

/**
 * @author mazhixiu
 * @date 2021/3/30 9:23
 * @Email:861359297@qq.com
 */
public interface OrderItemService {
    public int addOrderItem(OrderItem OrderItem);
    public int updateOrderItem(OrderItem orderItem);
    public List<OrderItem> queryOrderItemByStatus(String status);
    public List<OrderItem> queryAllOrderItem();
    public OrderItem queryOrderItemById( int id);
    public OrderItem queryOrderItemByUUID(String uuid);
    public int deleteOrderItem( int id);
}
