package org.fisco.bcos.service;


import org.apache.ibatis.annotations.Param;
import org.fisco.bcos.entity.Order;

import java.util.List;

/**
 * @author mazhixiu
 * @date 2021/3/29 17:08
 * @Email:861359297@qq.com
 */
public interface OrderService {
    public int addOrder(Order Order);
    public int updateOrder(Order Order);
    public List<Order> queryOrderBySupplier( String supplier);
    public List<Order> queryOrderByBuyer( String buyer);
    public List<Order> queryAllOrder();
    public int deleteOrder( int id);
    public Order queryOrderById( int id);
    public List<Order> queryOrderByBuyerAndStatus(String buyer,String status);
    public List<Order> queryOrderBySupplierAndStatus( String supplier,String status);
    public Order queryOrderByUUId(String id);
}
