package org.fisco.bcos.service;

import org.apache.ibatis.annotations.Param;
import org.fisco.bcos.entity.Respository;

import java.util.List;

public interface RespositoryService {
    public int addRespository(Respository respository);
    public int updateRespository(Respository respository);
    public int deleteRespository(int id);
    public List<Respository> queryAllRespository();
    public Respository queryRespositoryByID(int id);
    public List<Respository> queryRespositoryByHolder(String holder);
    public List<Respository> queryRespositoryByHolderAndStatus(String holder,String status);
    public List<Respository> queryRespositoryByLogistics(String logistics);
    public List<Respository> queryRespositoryByLogisticsAndStatus(String logistics,String status);
    public List<Respository> queryRespositoryByStatus(String status);
//    public List<Respository> queryMyRespository(String name);
public Respository queryRespositoryByNameAndSpecification(String name,String specification);
}
