package org.fisco.bcos.service;

import org.apache.ibatis.annotations.Param;
import org.fisco.bcos.entity.TokenExchange;

import java.util.List;

public interface TokenExchangeService {
    public int addTokenExchange(TokenExchange tokenExchange);
    public int updateTokenExchange(TokenExchange tokenExchange);
    public int deleteTokenExchange( int id);
    public List<TokenExchange> queryAllTTokenExchange();
    public List<TokenExchange> queryTokenExchangeByBank(String bank);
    public List<TokenExchange> queryTokenExchangeByInitiator( String initiator);
    public List<TokenExchange> queryTokenExchangeByInitiatorAndBank( String initiator,String bank);
    public TokenExchange queryTokenExchangeByID( int id);
    public List<TokenExchange> queryTokenExchangeByBankAndStatus( String bank,String status);
    public List<TokenExchange> queryTokenExchangeByInitiatorAndStatus(String initiator,String status);
}
