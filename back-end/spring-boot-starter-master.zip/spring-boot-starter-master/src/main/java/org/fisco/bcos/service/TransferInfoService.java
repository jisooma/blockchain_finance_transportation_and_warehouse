package org.fisco.bcos.service;

import org.apache.ibatis.annotations.Param;
import org.fisco.bcos.entity.TransferInfo;

import java.util.List;

public interface TransferInfoService {
    public int addTransferInfo(TransferInfo transferInfo);
    public List<TransferInfo> queryMyTransferInfo(String name);
    public List<TransferInfo> queryMyTransferInfoByType(String name,String type);
    public List<TransferInfo> queryTransferInfoByPayee( String payee);
    public List<TransferInfo> queryTransferInfoByPayer( String payer);
    public List<TransferInfo> queryAllTransferInfo();
    public int deleteTransferInfo( int id);
    public List<TransferInfo> queryTransferInfoByPayerAndType(String payer, String type);
    public List<TransferInfo> queryTransferInfoByPayeeAndType( String payee, String type);
}
