package org.fisco.bcos.service;

import org.apache.ibatis.annotations.Param;
import org.fisco.bcos.entity.ValueReport;

import java.util.List;

public interface ValueReportService {
    public int addValueReport(ValueReport valueReport);
    public int deleteValueReport( int id);
    public List<ValueReport> queryAllValueReport();
    public ValueReport queryValueReportByReno(int reno);
    public List<ValueReport> queryValueReportByLogistics(String logistics);
    public List<ValueReport> queryAllValueReportByEnterPrise(String enterprise);
}
