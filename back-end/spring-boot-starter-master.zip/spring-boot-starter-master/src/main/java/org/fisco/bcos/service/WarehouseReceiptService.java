package org.fisco.bcos.service;


import org.apache.ibatis.annotations.Param;
import org.fisco.bcos.entity.WarehouseReceipt;

import java.sql.Timestamp;
import java.util.List;

/**
 * @author mazhixiu
 * @date 2021/3/21 17:08
 * @Email:861359297@qq.com
 */
public interface WarehouseReceiptService {
    public int addWarehouseReceipt(WarehouseReceipt WarehouseReceipt);
    public int updateWarehouseReceipt(WarehouseReceipt WarehouseReceipt);
    public int deleteWarehouseReceipt(int id);
    public List<WarehouseReceipt> queryAllWarehouseReceipt();
    public WarehouseReceipt queryWarehouseReceiptByID(int id);
    public List<WarehouseReceipt> queryWarehouseReceiptByHolder( String holder);
    public List<WarehouseReceipt> queryWarehouseReceiptByLogistics( String logistics);
    public List<WarehouseReceipt> queryWarehouseReceiptByLogisticsAndHolder( String logistics,String holder);
    public WarehouseReceipt queryWarehouseReceiptByLogisticsAndHolderAndTime(String logistics, String holder, Timestamp time);
    public List<WarehouseReceipt> queryWarehouseReceiptByStatus(String status);
    public List<WarehouseReceipt> queryWarehouseReceiptByLogisticsAndStatus( String status,String logistics);
    public List<WarehouseReceipt> queryWarehouseReceiptByHolderAndStatus(String holder,String status);
}
