package org.fisco.bcos.utils;
;
import org.fisco.bcos.utils.paillier.PaillierKeyPair;
import org.junit.Test;

import java.io.*;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

/**
 * @author mazhixiu
 * @date 2021/3/16 16:11
 * @Email:861359297@qq.com
 */
public class PaillierTest {

    public static void generate_paillier_keypair() throws IOException {
        KeyPair keypair = PaillierKeyPair.generateGoodKeyPair();
        RSAPublicKey pubKey = (RSAPublicKey) keypair.getPublic();
        RSAPrivateCrtKey priKey = (RSAPrivateCrtKey) keypair.getPrivate();

        String publicKeyStr = PaillierKeyPair.publicKeyToPem(pubKey);
        String privateKeyStr = PaillierKeyPair.privateKeyToPem(priKey);
        // 写入公钥文件
        try {
            FileWriter fw = new FileWriter("pubKey.pem");
            fw.write("");//清空原文件内容
            fw.write(publicKeyStr);
            fw.flush();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 写入私钥文件
        try {
            FileWriter fw = new FileWriter("priKey.key");
            fw.write("");//清空原文件内容
            fw.write(privateKeyStr);
            fw.flush();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //读取公钥
    public static RSAPublicKey read_paillier_Pub() throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("pubKey.pem"));
        String s=null;
        StringBuffer publickey = new StringBuffer();
        while((s = br.readLine()) != null){
            publickey.append(s + "\n");
        }
        String s1 = publickey.toString();
        RSAPublicKey pubKey1 = (RSAPublicKey) PaillierKeyPair.pemToPublicKey(s1);
        br.close();
        return pubKey1;
    }
    //读取私钥
    public static RSAPrivateKey  read_paillier_Pri() throws IOException {
        BufferedReader brq = new BufferedReader(new FileReader("priKey.key"));
        String sq=null;
        StringBuffer privatekey = new StringBuffer();
        while((sq = brq.readLine()) != null){
            privatekey.append(sq + "\n");
        }
        RSAPrivateKey priKey1 = (RSAPrivateKey) PaillierKeyPair.pemToPrivateKey(privatekey.toString());
        brq.close();
        return priKey1;
    }
}
