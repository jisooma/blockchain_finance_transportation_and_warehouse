package org.fisco.bcos.utils.seal;
import lombok.Builder;
import lombok.Data;
@Builder
@Data
public class SealCircle {
    private Integer line;
    private Integer width;
    private Integer height;

    public Integer getLine() {
        return line;
    }

    public void setLine(Integer line) {
        this.line = line;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }
}