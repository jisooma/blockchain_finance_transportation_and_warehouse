//package org.fisco.bcos.utils.seal;
//
//import cn.hutool.core.io.FileUtil;
//
//
//import java.awt.*;
//import java.io.File;
//
//public class SealUtils {
//
//    public static void OfficialSeal_1(String path,String orgName) throws Exception {
//        FontMetrics fm;
//        SealFont font = null;
//        SealFont.builder().text(orgName).size(22).space(22.0).margin(4).build();
//        System.out.println(SealFont.builder().text(orgName).size(22).space(22.0).margin(4).build());
////        int textLen = font.getText().length();
////        int size = font.getSize() == null ? 25 + (10 - textLen) / 2 : font.getSize();
////
////        //3.字体样式
////        int style = font.getBold() ? Font.BOLD : Font.PLAIN;
////        Font f = new Font(font.getFamily(), style, size);
////        File file = FileUtil.file(path);
////        if (!file.exists()) {
////            file.getParentFile().mkdirs();
////        }
////        Seal.builder().size(200).borderCircle(SealCircle.builder().line(4).width(95).height(95).build())
////                .mainFont(SealFont.builder().text(orgName).size(22).space(22.0).margin(4).build())
////                .centerFont(SealFont.builder().text("★").size(60).build())
////                .titleFont(SealFont.builder().text("电子签章").size(16).space(8.0).margin(54).build()).build().draw(path);
////        System.out.println(sun.font.FontDesignMetrics.getMetrics(f));
//    }
//    public static void main(String[] args) {
//        try {
//            OfficialSeal_1("F:\\gl-file\\upload\\seal\\enterprise_1.png", "test999999股份公司_1");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}